#! /bin/bash
g++ -o Server main_server.cpp lib/src/server.cpp ../lib/src/monitor.cpp
