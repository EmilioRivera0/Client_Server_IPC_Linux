#! /bin/bash
g++ -o Client main_client.cpp lib/src/client.cpp ../lib/src/monitor.cpp
